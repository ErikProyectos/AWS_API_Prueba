"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WidgetTypes = void 0;
var WidgetTypes;
(function (WidgetTypes) {
    WidgetTypes["BarGraph"] = "barGraph";
    WidgetTypes["PieGraph"] = "pieGraph";
    WidgetTypes["Image"] = "image";
    WidgetTypes["Table"] = "table";
    WidgetTypes["Card"] = "card";
})(WidgetTypes || (exports.WidgetTypes = WidgetTypes = {}));
