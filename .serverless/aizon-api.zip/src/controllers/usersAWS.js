"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateUserAWS = exports.deleteUserAWS = exports.getAllUsersAWS = void 0;
const aws_sdk_1 = require("aws-sdk");
const dynamoDB = new aws_sdk_1.DynamoDB.DocumentClient();
const getAllUsersAWS = (_event) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        // Realizamos una consulta a la tabla de DynamoDB para obtener todos los usuarios
        const params = {
            TableName: 'UsersTable' // Nombre de tu tabla en DynamoDB
        };
        const result = yield dynamoDB.scan(params).promise();
        return {
            statusCode: 200,
            body: JSON.stringify(result.Items)
        };
    }
    catch (error) {
        console.log(error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Internal server error' })
        };
    }
});
exports.getAllUsersAWS = getAllUsersAWS;
const deleteUserAWS = (event) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { id } = event.pathParameters;
        const params = {
            TableName: 'UsersTable', // Nombre de tu tabla en DynamoDB
            Key: {
                _id: id // Suponiendo que 'id' es la clave primaria de tu tabla
            },
            ReturnValues: 'ALL_OLD' // Para devolver el elemento eliminado
        };
        const result = yield dynamoDB.delete(params).promise();
        return {
            statusCode: 200,
            body: JSON.stringify(result.Attributes)
        };
    }
    catch (error) {
        console.log(error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Internal server error' })
        };
    }
});
exports.deleteUserAWS = deleteUserAWS;
const updateUserAWS = (event) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { id } = event.pathParameters;
        const { username } = event.body;
        if (!username) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: 'Missing username in request body' })
            };
        }
        // Primero obtenemos el usuario de la base de datos
        const getUserParams = {
            TableName: 'UsersTable', // Nombre de tu tabla en DynamoDB
            Key: {
                _id: id // Suponiendo que 'id' es la clave primaria de tu tabla
            }
        };
        const existingUser = yield dynamoDB.get(getUserParams).promise();
        if (!existingUser.Item) {
            return {
                statusCode: 404,
                body: JSON.stringify({ message: 'User not found' })
            };
        }
        // Actualizamos el nombre de usuario del usuario obtenido
        const updateUserParams = {
            TableName: 'UsersTable', // Nombre de tu tabla en DynamoDB
            Key: {
                _id: id
            },
            UpdateExpression: 'SET #username = :username',
            ExpressionAttributeNames: {
                '#username': 'username'
            },
            ExpressionAttributeValues: {
                ':username': username
            },
            ReturnValues: 'ALL_NEW' // Para devolver el elemento actualizado
        };
        const updatedUser = yield dynamoDB.update(updateUserParams).promise();
        return {
            statusCode: 200,
            body: JSON.stringify(updatedUser.Attributes)
        };
    }
    catch (error) {
        console.log(error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Internal server error' })
        };
    }
});
exports.updateUserAWS = updateUserAWS;
