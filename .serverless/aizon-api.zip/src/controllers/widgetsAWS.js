"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateWidgetAWS = exports.deleteWidgetAWS = exports.getOneWidgetByIdAWS = exports.getAllWidgetsByScreenAWS = exports.newWidgetAWS = void 0;
const aws_sdk_1 = require("aws-sdk");
const dynamoDB = new aws_sdk_1.DynamoDB.DocumentClient();
const typesOfWidgets = ['barGraph', 'pieGraph', 'table', 'card'];
const newWidgetAWS = (event) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { name, screenId, type, src, values } = event.body;
        let widget;
        if (!screenId || !name || !type) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: 'Missing required fields' })
            };
        }
        const paramsSearch = {
            TableName: 'ScreensTable', // Nombre de tu tabla en DynamoDB
            Key: {
                _id: screenId
            }
        };
        const result = yield dynamoDB.get(paramsSearch).promise();
        if (!result.Item) {
            return {
                statusCode: 404, // Not Found
                body: JSON.stringify({ message: 'Screen not found' })
            };
        }
        if (!typesOfWidgets.includes(type)) {
            widget = {
                _id: Math.random().toString(36).substr(2, 9),
                screenId,
                name,
                type,
                src
            };
        }
        else {
            widget = {
                _id: Math.random().toString(36).substr(2, 9),
                screenId,
                name,
                type,
                values
            };
        }
        const params = {
            TableName: 'WidgetsTable', // Nombre de tu tabla en DynamoDB
            Item: widget
        };
        yield dynamoDB.put(params).promise();
        return {
            statusCode: 200,
            body: JSON.stringify(widget)
        };
    }
    catch (error) {
        console.log(error);
        return {
            statusCode: 500, // Internal Server Error
            body: JSON.stringify({ message: 'Internal server error' })
        };
    }
});
exports.newWidgetAWS = newWidgetAWS;
const getAllWidgetsByScreenAWS = (event) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { screenId } = event.body;
        const params = {
            TableName: 'WidgetsTable', // Nombre de tu tabla en DynamoDB
            IndexName: 'ScreenIndex', // Nombre de tu índice global secundario en DynamoDB
            KeyConditionExpression: 'screenId = :screenId',
            ExpressionAttributeValues: {
                ':screenId': screenId
            }
        };
        const result = yield dynamoDB.query(params).promise();
        return {
            statusCode: 200,
            body: JSON.stringify(result.Items)
        };
    }
    catch (error) {
        console.log(error);
        return {
            statusCode: 500, // Internal Server Error
            body: JSON.stringify({ message: 'Internal server error' })
        };
    }
});
exports.getAllWidgetsByScreenAWS = getAllWidgetsByScreenAWS;
const getOneWidgetByIdAWS = (event) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { id } = event.pathParameters;
        const params = {
            TableName: 'WidgetsTable', // Nombre de tu tabla en DynamoDB
            Key: {
                _id: id
            }
        };
        const result = yield dynamoDB.get(params).promise();
        if (!result.Item) {
            return {
                statusCode: 404, // Not Found
                body: JSON.stringify({ message: 'Widget not found' })
            };
        }
        return {
            statusCode: 200,
            body: JSON.stringify(result.Item)
        };
    }
    catch (error) {
        console.log(error);
        return {
            statusCode: 500, // Internal Server Error
            body: JSON.stringify({ message: 'Internal server error' })
        };
    }
});
exports.getOneWidgetByIdAWS = getOneWidgetByIdAWS;
const deleteWidgetAWS = (event) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { id } = event.pathParameters;
        const params = {
            TableName: 'WidgetsTable', // Nombre de tu tabla en DynamoDB
            Key: {
                _id: id
            }
        };
        const result = yield dynamoDB.delete(params).promise();
        return {
            statusCode: 200,
            body: JSON.stringify(result.Attributes)
        };
    }
    catch (error) {
        console.log(error);
        return {
            statusCode: 500, // Internal Server Error
            body: JSON.stringify({ message: 'Internal server error' })
        };
    }
});
exports.deleteWidgetAWS = deleteWidgetAWS;
const updateWidgetAWS = (event) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { id } = event.pathParameters;
        const { type, name, src, values } = event.body;
        const params = {
            TableName: 'WidgetsTable', // Nombre de tu tabla en DynamoDB
            Key: {
                _id: id
            },
            UpdateExpression: 'set #name = :name, #type = :type, #src = :src, #values = :values',
            ExpressionAttributeNames: {
                '#name': 'name',
                '#type': 'type',
                '#src': 'src',
                '#values': 'values'
            },
            ExpressionAttributeValues: {
                ':name': name,
                ':type': type,
                ':src': src,
                ':values': values
            },
            ReturnValues: 'ALL_NEW'
        };
        const result = yield dynamoDB.update(params).promise();
        return {
            statusCode: 200,
            body: JSON.stringify(result.Attributes)
        };
    }
    catch (error) {
        console.log(error);
        return {
            statusCode: 500, // Internal Server Error
            body: JSON.stringify({ message: 'Internal server error' })
        };
    }
});
exports.updateWidgetAWS = updateWidgetAWS;
