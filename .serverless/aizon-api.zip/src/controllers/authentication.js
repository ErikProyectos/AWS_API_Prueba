"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerAWS = exports.register = exports.login = exports.loginAWS = void 0;
const users_1 = require("../db/users");
const helpers_1 = require("../helpers");
const aws_sdk_1 = __importDefault(require("aws-sdk"));
const yup = __importStar(require("yup"));
const dynamoDB = new aws_sdk_1.default.DynamoDB.DocumentClient();
const cognito = new aws_sdk_1.default.CognitoIdentityServiceProvider();
const schema = yup.object().shape({
    username: yup.string().required(),
    password: yup.string().required(),
    email: yup.string().required()
});
const loginAWS = (event) => __awaiter(void 0, void 0, void 0, function* () {
    const { username, password } = event.body;
    try {
        const authResult = yield cognito.adminInitiateAuth({
            AuthFlow: 'ADMIN_NO_SRP_AUTH',
            ClientId: 'TU_CLIENT_ID',
            UserPoolId: 'TU_USER_POOL_ID',
            AuthParameters: {
                USERNAME: username,
                PASSWORD: password
            }
        }).promise();
        // Si el login es exitoso, devolvemos un token de autenticación
        return {
            statusCode: 200,
            body: JSON.stringify({
                token: authResult.AuthenticationResult.AccessToken
            })
        };
    }
    catch (error) {
        // Manejo de errores, por ejemplo, credenciales incorrectas
        return {
            statusCode: 401,
            body: JSON.stringify({ message: 'Credenciales incorrectas' })
        };
    }
});
exports.loginAWS = loginAWS;
/**
 * The login function in TypeScript handles user authentication by checking email and password,
 * generating session tokens, and setting cookies.
 * @param req - The `req` parameter in the `login` function is an object representing the HTTP
 * request. It contains information about the request made to the server, such as the request
 * headers, body, parameters, and more. In this case, it is specifically of type
 * `express.Request`, which is a type
 * @param res - The `res` parameter in the `login` function is an instance of
 * `express.Response`, which is used to send a response back to the client making the request.
 * It allows you to send HTTP responses with data such as status codes, headers, and the
 * response body. In the provided code snippet
 * @returns The login function returns different HTTP status codes based on the outcome of the
 * login process:
 * - If the email or password is missing in the request body, it returns a status of 400 (Bad
 * Request).
 * - If the user with the provided email is not found, it returns a status of 400.
 * - If the password provided does not match the stored password hash, it returns a status of
 */
const login = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { email, password } = req.body;
        if (!email || !password) {
            return res.sendStatus(400);
        }
        const user = yield (0, users_1.getUserByEmail)(email).select('+authentication.salt +authentication.password');
        if (!user) {
            return res.sendStatus(400);
        }
        const expectedHash = (0, helpers_1.authentication)(user.authentication.salt, password);
        if (user.authentication.password !== expectedHash) {
            return res.sendStatus(403);
        }
        const salt = (0, helpers_1.random)();
        user.authentication.sessionToken = (0, helpers_1.authentication)(salt, user._id.toString());
        yield user.save();
        res.cookie('USER-AUTH', user.authentication.sessionToken, { domain: 'localhost', path: '/' });
        return res.status(200).json(user).end();
    }
    catch (error) {
        console.log(error);
        return res.sendStatus(400);
    }
});
exports.login = login;
// eslint-disable-next-line @typescript-eslint/explicit-function-return-type
/**
 * The function `register` handles user registration by checking for required fields, verifying email
 * uniqueness, creating a new user with hashed password, and returning the user data.
 * @param req - The `req` parameter in the `register` function is an object representing the HTTP
 * request. It contains information about the request made by the client, such as request headers,
 * parameters, body, and more. In this specific function, `req` is of type `express.Request`, which is
 * a
 * @param res - The `res` parameter in the `register` function is an instance of `express.Response`. It
 * is used to send a response back to the client making the request. In the provided code snippet,
 * `res` is used to send different status codes and response data based on the outcome of the
 * registration
 * @returns If the registration is successful, a status of 200 along with the user object is being
 * returned. If there are missing fields in the request body or if a user with the same email already
 * exists, a status of 400 is being returned. If an error occurs during the registration process, a
 * status of 400 is also being returned.
 */
const register = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { email, password, username } = req.body;
        if (!email || !password || !username) {
            return res.sendStatus(400);
        }
        const existingUser = yield (0, users_1.getUserByEmail)(email);
        if (existingUser) {
            return res.sendStatus(400);
        }
        const salt = (0, helpers_1.random)();
        const user = yield (0, users_1.createUser)({
            email,
            username,
            authentication: {
                salt,
                password: (0, helpers_1.authentication)(salt, password)
            }
        });
        return res.status(200).json(user).end();
    }
    catch (error) {
        console.log(error);
        return res.sendStatus(400);
    }
});
exports.register = register;
const registerAWS = (event) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const reqBody = event.body;
        yield schema.validate(reqBody, { abortEarly: false });
        const user = Object.assign(Object.assign({}, reqBody), { _id: Math.random().toString(36).substr(2, 9) });
        const params = {
            TableName: 'UsersTable',
            Item: user
        };
        yield dynamoDB.put(params).promise();
        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'User registered successfully' })
        };
    }
    catch (error) {
        console.log(error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Internal server error' })
        };
    }
});
exports.registerAWS = registerAWS;
