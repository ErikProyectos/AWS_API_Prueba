"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerAWS = exports.loginAWS = void 0;
const aws_sdk_1 = __importDefault(require("aws-sdk"));
const yup = __importStar(require("yup"));
const dynamoDB = new aws_sdk_1.default.DynamoDB.DocumentClient();
const cognito = new aws_sdk_1.default.CognitoIdentityServiceProvider();
const schema = yup.object().shape({
    username: yup.string().required(),
    password: yup.string().required(),
    email: yup.string().required()
});
const loginAWS = (event) => __awaiter(void 0, void 0, void 0, function* () {
    const { username, password } = event.body;
    try {
        const authResult = yield cognito.adminInitiateAuth({
            AuthFlow: 'ADMIN_NO_SRP_AUTH',
            ClientId: 'TU_CLIENT_ID',
            UserPoolId: 'TU_USER_POOL_ID',
            AuthParameters: {
                USERNAME: username,
                PASSWORD: password
            }
        }).promise();
        // Si el login es exitoso, devolvemos un token de autenticación
        return {
            statusCode: 200,
            body: JSON.stringify({
                token: authResult.AuthenticationResult.AccessToken
            })
        };
    }
    catch (error) {
        // Manejo de errores, por ejemplo, credenciales incorrectas
        return {
            statusCode: 401,
            body: JSON.stringify({ message: 'Credenciales incorrectas' })
        };
    }
});
exports.loginAWS = loginAWS;
const registerAWS = (event) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const reqBody = event.body;
        yield schema.validate(reqBody, { abortEarly: false });
        const user = Object.assign(Object.assign({}, reqBody), { _id: Math.random().toString(36).substr(2, 9) });
        const params = {
            TableName: 'UsersTable',
            Item: user
        };
        yield dynamoDB.put(params).promise();
        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'User registered successfully' })
        };
    }
    catch (error) {
        console.log(error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Internal server error' })
        };
    }
});
exports.registerAWS = registerAWS;
