"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateSolutionAWS = exports.deleteSolutionAWS = exports.getOneSolutionByIdAWS = exports.getAllSolutionsByUserAWS = exports.newSolutionAWS = void 0;
const aws_sdk_1 = require("aws-sdk");
const dynamoDB = new aws_sdk_1.DynamoDB.DocumentClient();
const newSolutionAWS = (event) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { name, userId, comment } = event.body;
        // Verifica si UserId y name están presentes
        if (!userId || !name) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: 'Missing required fields' })
            };
        }
        // Crea la solución en DynamoDB
        const solutionParams = {
            TableName: 'SolutionsTable', // Nombre de tu tabla en DynamoDB
            Item: {
                _id: Math.random().toString(36).substr(2, 9),
                userId,
                name,
                comment
            }
        };
        yield dynamoDB.put(solutionParams).promise();
        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Solution created successfully' })
        };
    }
    catch (error) {
        console.log(error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Internal server error' })
        };
    }
});
exports.newSolutionAWS = newSolutionAWS;
const getAllSolutionsByUserAWS = (event) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { userId } = event.body;
        // Consultar todas las soluciones asociadas al usuario actual en DynamoDB
        const getSolutionParams = {
            TableName: 'SolutionsTable', // Nombre de tu tabla en DynamoDB
            Key: {
                userId
            }
        };
        const solutions = yield dynamoDB.query(getSolutionParams).promise();
        return {
            statusCode: 200,
            body: JSON.stringify(solutions.Items)
        };
    }
    catch (error) {
        console.log(error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Internal server error' })
        };
    }
});
exports.getAllSolutionsByUserAWS = getAllSolutionsByUserAWS;
const getOneSolutionByIdAWS = (event) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { id } = event.pathParameters;
        // Verifica si el ID es válido
        if (!id) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: 'Missing ID parameter' })
            };
        }
        // Consulta la solución existente en DynamoDB
        const getSolutionParams = {
            TableName: 'SolutionsTable', // Nombre de tu tabla en DynamoDB
            Key: {
                _id: id
            }
        };
        const solution = yield dynamoDB.get(getSolutionParams).promise();
        // Verifica si la solución existe
        if (!solution.Item) {
            return {
                statusCode: 404,
                body: JSON.stringify({ message: 'Solution not found' })
            };
        }
        return {
            statusCode: 200,
            body: JSON.stringify(solution.Item)
        };
    }
    catch (error) {
        console.log(error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Internal server error' })
        };
    }
});
exports.getOneSolutionByIdAWS = getOneSolutionByIdAWS;
const deleteSolutionAWS = (event) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { id } = event.pathParameters;
        // Verifica si el ID es válido
        if (!id) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: 'Missing ID parameter' })
            };
        }
        // Consulta la solución existente en DynamoDB
        const getSolutionParams = {
            TableName: 'SolutionsTable', // Nombre de tu tabla en DynamoDB
            Key: {
                _id: id
            }
        };
        const existingSolution = yield dynamoDB.get(getSolutionParams).promise();
        // Verifica si la solución existe
        if (!existingSolution.Item) {
            return {
                statusCode: 404,
                body: JSON.stringify({ message: 'Solution not found' })
            };
        }
        // Elimina la solución de DynamoDB
        const deleteSolutionParams = {
            TableName: 'SolutionsTable', // Nombre de tu tabla en DynamoDB
            Key: {
                _id: id
            },
            ReturnValues: 'ALL_OLD' // Para devolver el elemento eliminado
        };
        const deletedSolution = yield dynamoDB.delete(deleteSolutionParams).promise();
        return {
            statusCode: 200,
            body: JSON.stringify(deletedSolution.Attributes)
        };
    }
    catch (error) {
        console.log(error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Internal server error' })
        };
    }
});
exports.deleteSolutionAWS = deleteSolutionAWS;
const updateSolutionAWS = (event) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { id } = event.pathParameters;
        const { name, comment } = event.body;
        // Verifica si los campos obligatorios están presentes
        if (!name) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: 'Missing required fields' })
            };
        }
        // Consulta la solución existente en DynamoDB
        const getSolutionParams = {
            TableName: 'SolutionsTable', // Nombre de tu tabla en DynamoDB
            Key: {
                _id: id
            }
        };
        const existingSolution = yield dynamoDB.get(getSolutionParams).promise();
        // Verifica si la solución existe
        if (!existingSolution.Item) {
            return {
                statusCode: 404,
                body: JSON.stringify({ message: 'Solution not found' })
            };
        }
        // Actualiza los campos de la solución
        const updateSolutionParams = {
            TableName: 'SolutionsTable', // Nombre de tu tabla en DynamoDB
            Key: {
                _id: id
            },
            UpdateExpression: 'SET #name = :name, #comment = :comment',
            ExpressionAttributeNames: {
                '#name': 'name',
                '#comment': 'comment'
            },
            ExpressionAttributeValues: {
                ':name': name,
                ':comment': comment
            },
            ReturnValues: 'ALL_NEW' // Para devolver el elemento actualizado
        };
        const updatedSolution = yield dynamoDB.update(updateSolutionParams).promise();
        return {
            statusCode: 200,
            body: JSON.stringify(updatedSolution.Attributes)
        };
    }
    catch (error) {
        console.log(error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Internal server error' })
        };
    }
});
exports.updateSolutionAWS = updateSolutionAWS;
