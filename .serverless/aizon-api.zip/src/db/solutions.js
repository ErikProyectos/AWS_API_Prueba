"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateSolutionById = exports.deleteSolutionById = exports.getSolutionById = exports.getSolutionsByUserId = exports.createSolution = exports.SolutionModel = void 0;
/* eslint-disable @typescript-eslint/explicit-function-return-type */
const mongoose_1 = __importDefault(require("mongoose"));
const SolutionSchema = new mongoose_1.default.Schema({
    name: { type: String, required: true },
    userId: { type: mongoose_1.default.Types.ObjectId, ref: 'User' },
    comment: { type: String }
});
exports.SolutionModel = mongoose_1.default.model('Solution', SolutionSchema);
// Post function
const createSolution = (values) => new exports.SolutionModel(values).save().then((solution) => solution.toObject());
exports.createSolution = createSolution;
// Getters functions
const getSolutionsByUserId = (userId) => exports.SolutionModel.find({
    userId
});
exports.getSolutionsByUserId = getSolutionsByUserId;
const getSolutionById = (id) => exports.SolutionModel.findById({ _id: id });
exports.getSolutionById = getSolutionById;
// Delete function
const deleteSolutionById = (id) => exports.SolutionModel.findByIdAndDelete({ _id: id });
exports.deleteSolutionById = deleteSolutionById;
// Update function
const updateSolutionById = (id, values) => exports.SolutionModel.findByIdAndUpdate(id, values);
exports.updateSolutionById = updateSolutionById;
