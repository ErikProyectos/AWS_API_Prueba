"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateScreenById = exports.deleteScreenById = exports.getScreenById = exports.getScreensBySolutionId = exports.createScreen = exports.ScreenModel = void 0;
/* eslint-disable @typescript-eslint/explicit-function-return-type */
const mongoose_1 = __importDefault(require("mongoose"));
const ScreenSchema = new mongoose_1.default.Schema({
    name: { type: String, required: true },
    solutionId: { type: mongoose_1.default.Types.ObjectId, ref: 'Solution' },
    comment: { type: String }
});
exports.ScreenModel = mongoose_1.default.model('Screen', ScreenSchema);
// Post function
const createScreen = (values) => new exports.ScreenModel(values).save().then((screen) => screen.toObject());
exports.createScreen = createScreen;
// Getters functions
const getScreensBySolutionId = (solutionId) => exports.ScreenModel.find({
    solutionId
});
exports.getScreensBySolutionId = getScreensBySolutionId;
const getScreenById = (id) => exports.ScreenModel.findById({ _id: id });
exports.getScreenById = getScreenById;
// Delete function
const deleteScreenById = (id) => exports.ScreenModel.findByIdAndDelete({ _id: id });
exports.deleteScreenById = deleteScreenById;
// Update function
const updateScreenById = (id, values) => exports.ScreenModel.findByIdAndUpdate(id, values);
exports.updateScreenById = updateScreenById;
