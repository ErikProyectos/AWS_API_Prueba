"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateWidgetById = exports.deleteWidgetById = exports.getWidgetById = exports.getwidgetssByScreenId = exports.createWidget = exports.WidgetModel = void 0;
/* eslint-disable @typescript-eslint/explicit-function-return-type */
const mongoose_1 = __importDefault(require("mongoose"));
const types_1 = require("../types");
const WidgetsSchema = new mongoose_1.default.Schema({
    name: { type: String, required: true },
    screenId: { type: mongoose_1.default.Types.ObjectId, ref: 'Screen' },
    type: { type: String, required: true, enum: types_1.WidgetTypes },
    src: { type: String },
    values: { type: Array, any: [mongoose_1.default.Schema.Types.Mixed], default: undefined }
});
exports.WidgetModel = mongoose_1.default.model('Widget', WidgetsSchema);
// Post function
const createWidget = (values) => new exports.WidgetModel(values).save().then((widget) => widget.toObject());
exports.createWidget = createWidget;
// Getters functions
const getwidgetssByScreenId = (screenId) => exports.WidgetModel.find({
    screenId
});
exports.getwidgetssByScreenId = getwidgetssByScreenId;
const getWidgetById = (id) => exports.WidgetModel.findById({ _id: id });
exports.getWidgetById = getWidgetById;
// Delete function
const deleteWidgetById = (id) => exports.WidgetModel.findByIdAndDelete({ _id: id });
exports.deleteWidgetById = deleteWidgetById;
// Update function
const updateWidgetById = (id, values) => exports.WidgetModel.findByIdAndUpdate(id, values);
exports.updateWidgetById = updateWidgetById;
