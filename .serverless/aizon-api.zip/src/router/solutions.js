"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const middlewares_1 = require("../middlewares");
const solutions_1 = require("../controllers/solutions");
/* This code snippet is exporting a function that takes an instance of an Express Router as a
parameter. Inside the function, it sets up various routes for handling CRUD operations related to
solutions. Each route is associated with a specific HTTP method (POST, GET, DELETE, PATCH) and
corresponds to a specific controller function for handling the logic. */
exports.default = (router) => {
    router.post('/solutions', middlewares_1.isAuthenticated, solutions_1.newSolution);
    router.get('/solutions', middlewares_1.isAuthenticated, solutions_1.getAllSolutionsByUser);
    router.get('/solutions/:id', middlewares_1.isAuthenticated, solutions_1.getOneSolutionById);
    router.delete('/solutions/:id', middlewares_1.isAuthenticated, solutions_1.deleteSolution);
    router.patch('/solutions/:id', middlewares_1.isAuthenticated, solutions_1.updateSolution);
};
