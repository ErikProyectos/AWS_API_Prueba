"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const authentication_1 = __importDefault(require("./authentication"));
const users_1 = __importDefault(require("./users"));
const solutions_1 = __importDefault(require("./solutions"));
const screens_1 = __importDefault(require("./screens"));
const widgets_1 = __importDefault(require("./widgets"));
const router = express_1.default.Router();
/* This code snippet is exporting a default function that returns an instance of an Express Router.
Inside the function, it is registering various routes by calling functions like `authentication`,
`users`, `solutions`, `screens`, and `widgets` with the router instance as an argument. These
functions are likely responsible for setting up routes related to authentication, user management,
solutions, screens, and widgets in the application. Finally, the function returns the configured
router instance. */
exports.default = () => {
    (0, authentication_1.default)(router);
    (0, users_1.default)(router);
    (0, solutions_1.default)(router);
    (0, screens_1.default)(router);
    (0, widgets_1.default)(router);
    return router;
};
