"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const middlewares_1 = require("../middlewares");
const widgets_1 = require("../controllers/widgets");
/* This code snippet is exporting a function that takes an Express router as a parameter. Inside the
function, it sets up various routes for handling widget-related operations. Each route is associated
with a specific HTTP method (POST, GET, DELETE, PATCH) and corresponds to a different widget
controller function (newWidget, getAllWidgetsByScreen, getOneWidgetById, deleteWidget,
updateWidget). Additionally, the `isAuthenticated` middleware is applied to all these routes to
ensure that only authenticated users can access them. */
exports.default = (router) => {
    router.post('/widgets', middlewares_1.isAuthenticated, widgets_1.newWidget);
    router.get('/widgets', middlewares_1.isAuthenticated, widgets_1.getAllWidgetsByScreen);
    router.get('/widgets/:id', middlewares_1.isAuthenticated, widgets_1.getOneWidgetById);
    router.delete('/widgets/:id', middlewares_1.isAuthenticated, widgets_1.deleteWidget);
    router.patch('/widgets/:id', middlewares_1.isAuthenticated, widgets_1.updateWidget);
};
