"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const middlewares_1 = require("../middlewares");
const screens_1 = require("../controllers/screens");
/* This code snippet is exporting a function as the default export. The function takes in an
`express.Router` object as a parameter. Inside the function, it sets up various routes using the
`router` object for handling different HTTP methods like POST, GET, DELETE, and PATCH related to
screens. */
exports.default = (router) => {
    router.post('/screens', middlewares_1.isAuthenticated, screens_1.newScreen);
    router.get('/screens', middlewares_1.isAuthenticated, screens_1.getAllScreensBySolution);
    router.get('/screens/:id', middlewares_1.isAuthenticated, screens_1.getOneScreenById);
    router.delete('/screens/:id', middlewares_1.isAuthenticated, screens_1.deleteScreen);
    router.patch('/screens/:id', middlewares_1.isAuthenticated, screens_1.updateScreen);
};
