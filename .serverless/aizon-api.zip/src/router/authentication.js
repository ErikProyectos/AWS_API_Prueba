"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const authentication_1 = require("../controllers/authentication");
// const router = express.Router()
/* This code is exporting a default function that takes an Express router as a parameter. Inside the
function, it defines two POST routes for registering and logging in users by calling the `register`
and `login` functions from the `../controllers/authentication` module. This function is intended to
be used to set up authentication routes in an Express application. */
exports.default = (router) => {
    router.post('/auth/register', authentication_1.register);
    router.post('/auth/login', authentication_1.login);
};
