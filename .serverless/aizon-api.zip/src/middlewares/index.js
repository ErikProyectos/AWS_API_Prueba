"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.isAuthenticated = exports.isOwner = exports.isAuthenticatedAWS = void 0;
const lodash_1 = require("lodash");
const users_1 = require("../db/users");
const isAuthenticatedAWS = (event) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const sessionToken = event.authorizationToken;
        if (!sessionToken) {
            return generatePolicy('user', 'Deny', event.methodArn);
        }
        const existingUser = yield (0, users_1.getUserBySessionToken)(sessionToken);
        if (!existingUser) {
            return generatePolicy('user', 'Deny', event.methodArn);
        }
        return generatePolicy('user', 'Allow', event.methodArn);
    }
    catch (error) {
        console.log(error);
        return generatePolicy('user', 'Deny', event.methodArn);
    }
});
exports.isAuthenticatedAWS = isAuthenticatedAWS;
const generatePolicy = (principalId, effect, resource) => {
    return {
        principalId,
        policyDocument: {
            Version: '2012-10-17',
            Statement: [{
                    Action: 'execute-api:Invoke',
                    Effect: effect,
                    Resource: resource
                }]
        }
    };
};
const isOwner = (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { id } = req.params;
        const currentUserId = (0, lodash_1.get)(req, 'identity._id');
        if (!currentUserId) {
            return res.sendStatus(403);
        }
        if (currentUserId.toString() !== id) {
            return res.sendStatus(403);
        }
        return next();
    }
    catch (error) {
        console.log(error);
        return res.sendStatus(400);
    }
});
exports.isOwner = isOwner;
const isAuthenticated = (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const sessionToken = req.cookies['USER-AUTH'];
        if (!sessionToken) {
            return res.sendStatus(403);
        }
        const existingUser = yield (0, users_1.getUserBySessionToken)(sessionToken);
        if (!existingUser) {
            return res.sendStatus(403);
        }
        (0, lodash_1.merge)(req, { identity: existingUser });
        return next();
    }
    catch (error) {
        console.log(error);
        return res.sendStatus(400);
    }
});
exports.isAuthenticated = isAuthenticated;
